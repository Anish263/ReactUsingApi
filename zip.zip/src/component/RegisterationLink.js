import React from 'react';
import { Link } from 'react-router-dom';


function RegistrationLink() {
    return <div>
        <Link to="/">Doesn't have account? Register here !</Link>
    </div>;
}
 
export default RegistrationLink;